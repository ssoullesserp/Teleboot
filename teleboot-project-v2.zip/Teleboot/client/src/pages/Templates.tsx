import React, { useState, useEffect } from 'react';
import { FileText, Download, Eye, Users, MessageSquare } from 'lucide-react';
import { templateService } from '../services/templateService';
import { botService } from '../services/botService';
import { Template } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import toast from 'react-hot-toast';

export const Templates: React.FC = () => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [usingTemplate, setUsingTemplate] = useState<string | null>(null);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    try {
      const templatesData = await templateService.getTemplates();
      setTemplates(templatesData);
    } catch (error) {
      console.error('Failed to load templates:', error);
      toast.error('Failed to load templates');
    } finally {
      setLoading(false);
    }
  };

  const useTemplate = async (template: Template) => {
    setUsingTemplate(template.id);
    try {
      // Create a new bot based on the template
      const newBot = await botService.createBot({
        name: `${template.name} Bot`,
        description: `Bot created from ${template.name} template`
      });
      
      // TODO: Create a flow based on the template's flow_data
      // This would involve calling flowService.createFlow with the template's flow_data
      
      toast.success(`Bot created from ${template.name} template!`);
      // TODO: Navigate to the bot builder page
    } catch (error) {
      console.error('Failed to use template:', error);
      toast.error('Failed to create bot from template');
    } finally {
      setUsingTemplate(null);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case 'support':
        return Users;
      case 'marketing':
        return MessageSquare;
      default:
        return FileText;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case 'support':
        return 'bg-blue-100 text-blue-800';
      case 'marketing':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Bot Templates</h1>
        <p className="text-gray-600">Choose from pre-built bot templates to get started quickly</p>
      </div>

      {templates.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No templates available</h3>
          <p className="text-gray-500">Templates will be loaded when the server starts</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => {
            const IconComponent = getCategoryIcon(template.category);
            const isUsing = usingTemplate === template.id;
            
            return (
              <div key={template.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <IconComponent className="h-8 w-8 text-primary-600" />
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(template.category)}`}>
                    {template.category}
                  </span>
                </div>
                
                <h3 className="font-semibold text-gray-900 mb-2">{template.name}</h3>
                {template.description && (
                  <p className="text-gray-600 text-sm mb-4">{template.description}</p>
                )}
                
                <div className="text-xs text-gray-500 mb-4">
                  {template.flow_data?.nodes?.length || 0} nodes • 
                  {template.flow_data?.edges?.length || 0} connections
                </div>
                
                <div className="flex gap-2">
                  <button className="btn btn-outline flex-1 text-xs">
                    <Eye className="h-3 w-3 mr-1" />
                    Preview
                  </button>
                  <button 
                    onClick={() => useTemplate(template)}
                    disabled={isUsing}
                    className="btn btn-primary flex-1 text-xs"
                  >
                    {isUsing ? (
                      <LoadingSpinner />
                    ) : (
                      <>
                        <Download className="h-3 w-3 mr-1" />
                        Use Template
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};