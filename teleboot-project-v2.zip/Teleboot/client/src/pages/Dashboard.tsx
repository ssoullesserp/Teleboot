import React, { useState, useEffect } from 'react';
import { Plus, Bot, Settings, Play, Trash2 } from 'lucide-react';
import { botService } from '../services/botService';
import { Bot as BotType } from '../types';
import { LoadingSpinner } from '../components/LoadingSpinner';
import toast from 'react-hot-toast';

export const Dashboard: React.FC = () => {
  const [bots, setBots] = useState<BotType[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadBots();
  }, []);

  const loadBots = async () => {
    try {
      const botsData = await botService.getBots();
      setBots(botsData);
    } catch (error) {
      console.error('Failed to load bots:', error);
      toast.error('Failed to load bots');
    } finally {
      setLoading(false);
    }
  };

  const createBot = async () => {
    setCreating(true);
    try {
      const newBot = await botService.createBot({
        name: `My Bot ${bots.length + 1}`,
        description: 'A new Telegram bot'
      });
      setBots([newBot, ...bots]);
      toast.success('Bot created successfully!');
    } catch (error) {
      console.error('Failed to create bot:', error);
      toast.error('Failed to create bot');
    } finally {
      setCreating(false);
    }
  };

  const deleteBot = async (botId: string) => {
    if (!window.confirm('Are you sure you want to delete this bot?')) return;
    
    try {
      await botService.deleteBot(botId);
      setBots(bots.filter(bot => bot.id !== botId));
      toast.success('Bot deleted successfully');
    } catch (error) {
      console.error('Failed to delete bot:', error);
      toast.error('Failed to delete bot');
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">My Bots</h1>
          <p className="text-gray-600">Create and manage your Telegram bots</p>
        </div>
        <button
          onClick={createBot}
          disabled={creating}
          className="btn btn-primary flex items-center gap-2"
        >
          {creating ? <LoadingSpinner /> : <Plus className="h-4 w-4" />}
          Create Bot
        </button>
      </div>

      {bots.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <Bot className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No bots yet</h3>
          <p className="text-gray-500 mb-6">Create your first Telegram bot to get started</p>
          <button 
            onClick={createBot} 
            disabled={creating}
            className="btn btn-primary flex items-center gap-2 mx-auto"
          >
            {creating ? <LoadingSpinner /> : <Plus className="h-4 w-4" />}
            Create Your First Bot
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {bots.map((bot) => (
            <div key={bot.id} className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <Bot className="h-8 w-8 text-primary-600" />
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                  bot.is_active 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {bot.is_active ? 'Active' : 'Inactive'}
                </span>
              </div>
              
              <h3 className="font-semibold text-gray-900 mb-2">{bot.name}</h3>
              {bot.description && (
                <p className="text-gray-600 text-sm mb-4">{bot.description}</p>
              )}
              
              <div className="text-xs text-gray-500 mb-4">
                Created: {new Date(bot.created_at).toLocaleDateString()}
              </div>
              
              <div className="flex gap-2">
                <button className="btn btn-outline flex-1 text-xs">
                  <Settings className="h-3 w-3 mr-1" />
                  Edit
                </button>
                <button className="btn btn-primary flex-1 text-xs">
                  <Play className="h-3 w-3 mr-1" />
                  Build
                </button>
                <button 
                  onClick={() => deleteBot(bot.id)}
                  className="btn bg-red-50 text-red-600 hover:bg-red-100 px-2"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};