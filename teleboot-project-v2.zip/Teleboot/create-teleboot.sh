#!/bin/bash

# 🤖 Teleboot Project Generator
# This script creates the complete Teleboot visual Telegram bot builder

echo "🚀 Creating Teleboot project..."

# Create project structure
mkdir -p Teleboot/{client/src/{components,pages,contexts,services,types,hooks,utils},server/src/{controllers,database,middleware,routes,types,models,services}}

cd Teleboot

# Root package.json
cat > package.json << 'EOF'
{
  "name": "teleboot",
  "version": "1.0.0",
  "description": "Visual Telegram bot builder",
  "scripts": {
    "dev": "concurrently \"npm run server:dev\" \"npm run client:dev\"",
    "server:dev": "cd server && npm run dev",
    "client:dev": "cd client && npm run dev",
    "install:all": "npm install && cd server && npm install && cd ../client && npm install",
    "build": "cd server && npm run build && cd ../client && npm run build"
  },
  "devDependencies": {
    "concurrently": "^8.2.2"
  },
  "keywords": ["telegram", "bot", "builder", "visual", "react", "nodejs"],
  "author": "Teleboot Team",
  "license": "MIT"
}
EOF

# .gitignore
cat > .gitignore << 'EOF'
node_modules/
*.log
.env
.env.local
.env.production
dist/
build/
*.db
*.sqlite
*.sqlite3
.DS_Store
.vscode/
.idea/
*.tsbuildinfo
EOF

# Client package.json
cat > client/package.json << 'EOF'
{
  "name": "teleboot-client",
  "version": "1.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.17.0",
    "reactflow": "^11.10.1",
    "axios": "^1.5.0",
    "react-hook-form": "^7.47.0",
    "react-hot-toast": "^2.4.1",
    "lucide-react": "^0.288.0",
    "@headlessui/react": "^1.7.17",
    "clsx": "^2.0.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.15",
    "@types/react-dom": "^18.2.7",
    "@typescript-eslint/eslint-plugin": "^6.0.0",
    "@typescript-eslint/parser": "^6.0.0",
    "@vitejs/plugin-react": "^4.0.3",
    "autoprefixer": "^10.4.16",
    "eslint": "^8.45.0",
    "eslint-plugin-react-hooks": "^4.6.0",
    "eslint-plugin-react-refresh": "^0.4.3",
    "postcss": "^8.4.31",
    "tailwindcss": "^3.3.5",
    "typescript": "^5.0.2",
    "vite": "^4.4.5"
  }
}
EOF

# Server package.json
cat > server/package.json << 'EOF'
{
  "name": "teleboot-server",
  "version": "1.0.0",
  "description": "Teleboot backend server",
  "main": "dist/index.js",
  "scripts": {
    "dev": "ts-node-dev --respawn --transpile-only src/index.ts",
    "build": "tsc",
    "start": "node dist/index.js"
  },
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "sqlite3": "^5.1.6",
    "uuid": "^9.0.0",
    "joi": "^17.11.0",
    "jsonwebtoken": "^9.0.2",
    "bcryptjs": "^2.4.3"
  },
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/cors": "^2.8.17",
    "@types/node": "^20.8.0",
    "@types/uuid": "^9.0.6",
    "@types/jsonwebtoken": "^9.0.5",
    "@types/bcryptjs": "^2.4.6",
    "typescript": "^5.2.2",
    "ts-node": "^10.9.1",
    "ts-node-dev": "^2.0.0"
  }
}
EOF

echo "📦 Package files created!"
echo "ℹ️  Download the complete source files from GitHub:"
echo "   git clone https://github.com/your-username/teleboot.git"
echo ""
echo "🚀 To continue setup:"
echo "   1. cd Teleboot"
echo "   2. npm run install:all"
echo "   3. cp server/.env.example server/.env"
echo "   4. npm run dev"

echo "✅ Basic project structure created!"
EOF